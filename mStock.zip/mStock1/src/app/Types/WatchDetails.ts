import { CompanyDetails } from "./CompanyDetails";

export interface WatchDetails{
    id : number;
    Companies : CompanyDetails[]
}