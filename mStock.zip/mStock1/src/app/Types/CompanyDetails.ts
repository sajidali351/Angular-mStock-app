export interface CompanyDetails{
    CompanyCode : number,
    CompanyName : string,
    BriefDesc : string,
    CurrentStockPrice : number
}