export interface User{
  UserId : number,
  Email : string,
  Password : string
}