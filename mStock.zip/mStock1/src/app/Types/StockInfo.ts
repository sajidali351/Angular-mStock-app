export interface StockInfo{
    Date : Date,
    CompanyName : string,
    StockPrice : number
}